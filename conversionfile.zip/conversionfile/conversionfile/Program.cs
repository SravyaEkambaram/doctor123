﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace conversionfile
{
    class Program
    {
        static void Main(string[] args)
        {
            var filecount = (from file in Directory.EnumerateFiles(@"D:\\Sravya", "*.html", SearchOption.AllDirectories)
                             select file).Count();
            Console.WriteLine("The html file count is :"+filecount);
            DirectoryInfo d=new DirectoryInfo(@"D:\Sravya");
            FileInfo[] Files = d.GetFiles("*.html");
            string str = "";
            foreach (FileInfo file in Files)
            {
                str = str + "\n" + file.Name;
            }
            Console.WriteLine("\nHtml files present in Sravya folder are :" +str);
            
            listFilesInDirectory(@"D:\Sravya\");


            string folder_path = @"D:\Sravya";
            string[] folders = Directory.GetDirectories(folder_path);
            Console.WriteLine("the subfolder present in Sravya folder is:");
            foreach (string folder in folders)
            {
                Console.WriteLine(new DirectoryInfo(folder).Name);
            }
            DirectoryInfo d1 = new DirectoryInfo(@"D:\Sravya\subfolder");
            FileInfo[] Files1 = d1.GetFiles("*.html");
            string str2 = "";
            foreach (FileInfo file1 in Files1)
            {
                str2 = str2 + "\n" + file1.Name;
            }
            Console.WriteLine("\nHtml files present in Sravya subfolder are :" + str2);
           
            listFilesInDirectory1(@"D:\Sravya\subfolder");
            Console.WriteLine("press enter to continue");
            Console.ReadLine();
        }
        static void listFilesInDirectory(string workingDirectory)
        {
            string[] filePaths = Directory.GetFiles(workingDirectory);
            Console.WriteLine("\nPath of the files present in Sravya folder are : ");
            foreach (string filePath in filePaths)
            {
                Console.WriteLine(filePath);
            }
        }
        static void listFilesInDirectory1(string workingDirectory)
        {
            string[] filePaths1 = Directory.GetFiles(workingDirectory);
            Console.WriteLine("\nPath of the files present in subfolder are : ");
            foreach (string filePath1 in filePaths1)
            {
                Console.WriteLine(filePath1);
            }
        }
    }
}
